/**
 * 
 */
/**
 * @author Julie
 *
 */
module LawGame {
	requires java.desktop;
}